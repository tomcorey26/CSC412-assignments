var searchData=
[
  ['numcols_5',['numCols',['../structImageInfoStruct.html#abe08849e5ea6c8aab0cc67c41dc1b1fd',1,'ImageInfoStruct']]]
];
